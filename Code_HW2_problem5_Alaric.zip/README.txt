# Bioinformatics
This is HW2 of Bioinformatics
Coder: Alaric Wu


Note: 1.The input file is input.dat, for your convinience, please use *.dat as the format of your input file.
      2.The program is written in matlab, so the outputs are in matlab command windows.
      3.The excutable file is sequence_alignment.m